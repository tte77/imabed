-- tcm447：每次射击的 6 发子弹按固定角度散开，落点构成正六边形，无随机偏移。
-- calcSpread 返回值会作为局部坐标系里的 (x, y)，前方固定为 8。
-- hex_radius 写在枪械 data 的 script_param 里，可按手感调整。
local M = {}

function M.calcSpread(api, num, spread)
    local param = api:getScriptParams()
    local radius = 1.6
    if param ~= nil and param.hex_radius ~= nil then
        radius = param.hex_radius
    end
    -- num 从 0 到 5，每发固定间隔 60 度
    local angle = num * (math.pi / 3)
    return { math.cos(angle) * radius, math.sin(angle) * radius }
end

return M
